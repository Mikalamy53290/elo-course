-- ELO COURSE : limite de 10 filleuls par code parrain
create or replace function public.elocoins_capture_referral_on_account_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_code text; v_referrer uuid; v_used integer;
begin
 select upper(trim(coalesce(u.raw_user_meta_data->>'referral_code',''))) into v_code from auth.users u where u.id=new.user_id;
 if v_code is null or v_code='' then return new; end if;
 select w.user_id into v_referrer from public.elocoins_wallets w where upper(w.referral_code)=v_code limit 1 for update;
 if v_referrer is null or v_referrer=new.user_id then return new; end if;
 select count(*)::integer into v_used from public.elocoins_referrals where referrer_user_id=v_referrer and status in ('pending','validated');
 if v_used>=10 then return new; end if;
 insert into public.elocoins_referrals(referrer_user_id,referred_user_id,referral_code,status) values(v_referrer,new.user_id,v_code,'pending') on conflict(referred_user_id) do nothing;
 return new;
end; $$;
create or replace function public.elocoins_referral_usage(p_code text)
returns integer language sql security definer set search_path=public stable as $$
 select count(*)::integer from public.elocoins_referrals r join public.elocoins_wallets w on w.user_id=r.referrer_user_id where upper(w.referral_code)=upper(trim(p_code)) and r.status in ('pending','validated');
$$;
revoke all on function public.elocoins_referral_usage(text) from public;
grant execute on function public.elocoins_referral_usage(text) to anon, authenticated;